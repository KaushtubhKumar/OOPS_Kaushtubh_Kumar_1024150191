f = @(x) 1/(x*log(x));
a = exp(1);
b = exp(1) + 1;
n = 10;
h = (b-a)/n;
sum = 0;
for i = 1:(n-1)
    x = a + h*i;
    if rem(i,2) == 0
        sum = sum + 2*f(x);
    else    
        sum = sum + 4*f(x);
    end
end
sum = sum + f(a) + f(b);
ans = sum * (h / 3);
disp(ans);
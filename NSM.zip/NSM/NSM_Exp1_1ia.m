clc;
clear all;
f=@(x) x^2-29;
a=-6;
b=-5;
tol=0.001;
j=0;
while abs(a-b)>tol;
 c=(a+b)/2;
 if f(c)==0
  break;
 elseif f(a)*f(c)<0
  b=c;
 else
  a=c;
 end
 j=j+1;
end
fprintf('Root is %f',c)
j
f = @(t,i) -1.5*i;
t0 = 0;
i0 = 0.5;
h = 0.05;
tn = 1;
N = (tn-t0)/h;
t = zeros(1,N+1);
i = zeros(1,N+1);
t(1)=t0;
i(1)=i0;
for k=1:N
    t(k+1)=t(k)+h;
    ip = i(k) + h*f(t(k),i(k));
    i(k+1)= i(k) + (h/2)*( f(t(k),i(k)) + f(t(k+1),ip) );
end
disp('    t         i')
disp([t' i'])
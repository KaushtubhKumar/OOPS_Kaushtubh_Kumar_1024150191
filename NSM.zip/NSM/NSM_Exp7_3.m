n = 7;
x = [200 250 300 375 425 475 600];
f = [7.5 8.6 8.7 10 11.3 12.7 15.3];
p = 400;
F(:,1) = f';
for i = 2:n
    for j = i:n
        F(j,i) = (F(j,i-1) - F(j-1,i-1)) / (x(j) - x(j-i+1));
    end
end
for i = 1:n
    pr(i) = 1;
    for j = 1:i-1
        pr(i) = pr(i) * (p - x(j));
    end
end
sum = 0;
for i = 1:n
    sum = sum + (F(i,i) * pr(i));
end
disp(sum)
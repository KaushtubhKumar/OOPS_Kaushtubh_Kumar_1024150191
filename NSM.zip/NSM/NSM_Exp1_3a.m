clc;
clear all;
eps0 = 8.854e-12;
q = 1.25e-5;
Q = 1.25e-5;
a = 0.9;
F = 1.2;
k = 1/(4*pi*eps0);
% Define function
f = @(x) k*q*Q*x./(x.^2 + a^2).^(3/2) - F;
m=0;
n=1;
tol=0.0005;
j=0;
while abs(m-n)>tol;
 c=(m+n)/2;
 if f(c)==0
  break;
 elseif f(m)*f(c)<0
  n=c;
 else
  m=c;
 end
 j=j+1;
end
fprintf('Root is %f',c)
j
clc;
clear;
t = [0 8 16 24 32 40];
o = [14.621 11.843 9.870 8.418 7.305 6.413];
T = input('Enter the value of T = ');
n = numel(t);
l = zeros(1, n);
for i = 1:n
    t1 = t;
    t1(i) = [];
    l(i) = prod(T - t1) / prod(t(i) - t1);
end
O = sum(l .* o);
fprintf('Value of O at T = %.4f is %.6f\n', T, O);
g = @(x) sqrt(10/(4+x)) ;
syms x
h(x) = diff(g(x));
x0 = 1.5;
if abs(h(x0))>1
    fprintf('Convergence condition fails\n');
    return;
end
e = 0.001;
n = 20;
i = 1;
while i<=n
    x1 = g(x0);
    if abs(x0-x1)<e
        fprintf('%f\n%f', x1,i);
        break;
    end
    x0 = x1;
    i = i + 1;
end
if i > n
    fprintf('Method did not converge in %d iterations\n', n);
end
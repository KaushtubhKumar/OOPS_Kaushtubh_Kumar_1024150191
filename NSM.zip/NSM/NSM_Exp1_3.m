eps0 = 8.854e-12;
q = 1.25e-5;
Q = 1.25e-5;
a = 0.9;
F = 1.2;
k = 1/(4*pi*eps0);
% Define function
f = @(x) k*q*Q*x./(x.^2 + a^2).^(3/2) - F;
h=1;
N=1000;
for i=-N:h:N
 if f(i)*f(i+h)<0
  a=i
  b=i+h
 end
end
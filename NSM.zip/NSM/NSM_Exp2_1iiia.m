f = @(x) x - 2*sin(x);
h=1;
N=1000;
for i=-N:h:N
 if f(i)*f(i+h)<0
  a=i
  b=i+h
 end
end
Q = 1.5;
V = 5;
R = 2;
T = 1; 
f = @(x) x*V*(1 - exp(-T/(R*x))) - Q;
x0 = 0.5;
ep=10^(-3);
g = @(x) V*(1 - exp(-T/(R*x))) - (V*T/(R*x))*exp(-T/(R*x));
k = 1;
n = 100;
while(k<=n)
    x1=x0-(f(x0)/g(x0));
    if abs(x1-x0)<ep
        break;
    end
    x0=x1;
    k=k+1;
end
fprintf('The solution is %f and no. of iterations are %d' , x1, k);
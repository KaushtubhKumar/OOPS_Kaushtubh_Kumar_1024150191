A = [4 1 0;
     1 20 1;
     0 1 4];
x = [1; 1; 1];
ep= 1e-3;
K_old = 0;
error = 1;
iter = 0;
while error > ep
    y = A * x;
    K = max(abs(y));
    x = y / K;
    error = abs(K - K_old);
    K_old = K;
    iter = iter + 1;
end
fprintf('Largest Eigenvalue = %.6f\n', K);
fprintf('Corresponding Eigenvector:\n');
disp(x);
fprintf('Number of iterations = %d\n', iter);
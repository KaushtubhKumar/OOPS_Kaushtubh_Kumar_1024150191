n = 4;
x = [1 1.5 2 2.5];
y = [2.7183 4.4817 7.3891 12.1825];
f = 2.25;
Y(:,1) = y';
for i = 2:n
    for j = i:n
        Y(j,i) = (Y(j,i-1) - Y(j-1,i-1)) / (x(j) - x(j-i+1));
    end
end
for i = 1:n
    pr(i) = 1;
    for j = 1:i-1
        pr(i) = pr(i) * (f - x(j));
    end
end
sum = 0;
for i = 1:n
    sum = sum + (Y(i,i) * pr(i));
end
disp(sum)
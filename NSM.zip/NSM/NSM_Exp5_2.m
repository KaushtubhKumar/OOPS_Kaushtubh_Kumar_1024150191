A = [4.63 -1.21 3.22;
      -3.07 5.48 2.11;
      1.26 3.11 4.57];
b = [2.22;
     -3.17;
     5.11];
n = 3;
N = 100;
tol = 1e-3;
x0 = zeros(n,1);
x  = zeros(n,1);
for k = 1:N
    for i = 1:n
        sum1 = A(i,1:i-1) * x(1:i-1);
        sum2 = A(i,i+1:n) * x0(i+1:n);
        x(i) = (b(i) - sum1 - sum2) / A(i,i);
    end
    if abs(x - x0) < tol
        fprintf('Converged in %d iterations\n', k);
        fprintf('x1 = %.2f\n', x(1));
        fprintf('x2 = %.2f\n', x(2));
        fprintf('x3 = %.2f\n', x(3));
        return;
    end
    x0 = x;
end
fprintf('Did not converge in %d iterations\n', N);
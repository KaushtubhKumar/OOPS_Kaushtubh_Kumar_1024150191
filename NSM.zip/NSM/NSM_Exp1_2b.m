clc;
clear all;
L=5;
C=0.0001;
f=@(x) exp(-x/200)*cos(sqrt(1/(L*C)-(x^2/100))*0.05)-0.01;
a=328;
b=329;
tol=0.0005;
j=0;
while abs(a-b)>tol;
 c=(a+b)/2;
 if f(c)==0
  break;
 elseif f(a)*f(c)<0
  b=c;
 else
  a=c;
 end
 j=j+1;
end
fprintf('Root is %f',c)
j
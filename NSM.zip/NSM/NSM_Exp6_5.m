clc;
clear all;
x = [0.25 0.75 1.25 1.5 2];
v = [-0.45 -0.6 0.7 1.88 6];
X = input('Enter the value of X = ');
n = numel(x);
l = zeros(1, n);
for i = 1:n
    x1 = x;
    x1(i) = [];
    l(i) = prod(X - x1)./prod(x(i) - x1);
end
V = sum(l .* v);
fprintf('Value of V at X = %.4f is %.6f\n', X, V);
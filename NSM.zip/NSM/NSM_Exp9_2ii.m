f = @(t,i) -1.5*i;
t = 0;
i = 0.5;
h = 0.05;
tn = 1;
N = (tn-t)/h;
fprintf('    t          i\n');
for k = 1:N
    k1 = h*f(t,i);
    k2 = h*f(t+h/2, i+k1/2);
    k3 = h*f(t+h/2, i+k2/2);
    k4 = h*f(t+h, i+k3);
    i = i + (k1 + 2*k2 + 2*k3 + k4)/6;
    t = t + h;
    fprintf('%f   %f\n', t, i);
end
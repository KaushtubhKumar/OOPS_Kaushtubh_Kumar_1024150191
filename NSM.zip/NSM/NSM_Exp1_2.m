clc;
clear all;
L=5;
C=0.0001;
f=@(x) exp(-x/200)*cos(sqrt(1/(L*C)-(x^2/100))*0.05)-0.01;
h=1;
N=1000;
for i=-N:h:N
 if f(i)*f(i+h)<0
  a=i
  b=i+h
 end
end
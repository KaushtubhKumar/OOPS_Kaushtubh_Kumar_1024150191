L = 1;
C = 0.25;
R = 0.025;
w = sqrt(3.5);
h = 0.1;
t0 = 0;
tn = 1;
q = 0;
i = 0;
t = t0;
N = (tn-t0)/h;
fprintf('   t        q         i\n');
for k = 1:N
    k1q = h*i;
    k1i = h*(sin(w*t) - 0.025*i - 4*q);
    k2q = h*(i + k1i/2);
    k2i = h*(sin(w*(t+h/2)) - 0.025*(i+k1i/2) - 4*(q+k1q/2));
    k3q = h*(i + k2i/2);
    k3i = h*(sin(w*(t+h/2)) - 0.025*(i+k2i/2) - 4*(q+k2q/2));
    k4q = h*(i + k3i);
    k4i = h*(sin(w*(t+h)) - 0.025*(i+k3i) - 4*(q+k3q));
    q = q + (k1q + 2*k2q + 2*k3q + k4q)/6;
    i = i + (k1i + 2*k2i + 2*k3i + k4i)/6;
    t = t + h;
    fprintf('%f   %f   %f\n', t, q, i);
end
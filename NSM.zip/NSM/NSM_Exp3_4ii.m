g = @(x) (2e6 - 0.33*2e6*sqrt(x)) / (2e5);
syms x
h(x) = diff((2e6 - 0.33*2e6*sqrt(x)) / (2e5));
x0 = 4;
if abs(h(x0)) > 1
    fprintf('Convergence condition fails\n');
    return;
end
e = 0.01;
n = 100;
i = 1;
while i<=n
    x1 = g(x0);
    if abs(x0-x1)<e
        fprintf('%f\n%f', x1, i);
        break;
    end
    x0 = x1;
    i = i + 1;
end
if i > n
    fprintf('Method did not converge in %d iterations\n', n);
end
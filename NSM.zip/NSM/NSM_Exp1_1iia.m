clc;
clear all;
f=@(x) x^3+4*x^2-10;
a=1;
b=2;
tol=0.001;
j=0;
while abs(a-b)>tol;
 c=(a+b)/2;
 if f(c)==0
  break;
 elseif f(a)*f(c)<0
  b=c;
 else
  a=c;
 end
 j=j+1;
end
fprintf('Root is %f',c)
j
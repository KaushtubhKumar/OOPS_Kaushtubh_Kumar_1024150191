f = @(x) 5*exp(-1.25*x)*sin(2*pi*x);
a = 0;
b = 1/2;
n = 10;
h = (b-a)/n;
sum = 0;
for i = 1:(n-1)
    x = a + h*i;
    sum = sum + 2*f(x);
end
sum = sum + f(a) + f(b);
ans = sum * (h / 2);
ans = sqrt(ans);
disp(ans);
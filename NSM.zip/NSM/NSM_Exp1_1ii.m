clc;
clear all;
f=@(x) x^3+4*x^2-10;
h=1;
N=100;
for i=-N:h:N
 if f(i)*f(i+h)<0
  a=i
  b=i+h
 end
end
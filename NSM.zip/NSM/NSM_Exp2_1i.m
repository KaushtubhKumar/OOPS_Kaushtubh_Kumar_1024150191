f = @(x) x^2 - 17;
x0 = 0.5;
ep=10^(-5);
g = @(x) 2*x;
k=1;
n=100;
while k<=n
    x1=x0-(f(x0)/g(x0));
    if abs(x1-x0)<ep
        break;
    end
        k=k+1;
        x0=x1; 
end
fprintf('The solution is %f and no. of iterations are %d' , x1, k);
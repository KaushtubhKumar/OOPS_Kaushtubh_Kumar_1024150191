f = @(x) exp(-x)*(x^2 + 5*x + 2) + 1;
x0 = -1;
ep=10^(-5);
g = @(x) exp(-x)*((2*x + 5) - (x^2 + 5*x + 2));
k=1;
n=100;
while k<=n
    x1=x0-(f(x0)/g(x0));
    if abs(x1-x0)<ep
        break;
    end 
        k=k+1;
        x0=x1;
end
fprintf('The solution is %f and no. of iterations are %d' , x1, k);
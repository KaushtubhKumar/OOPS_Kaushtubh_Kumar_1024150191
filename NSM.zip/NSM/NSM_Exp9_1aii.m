f = @(x,y) -y + 2*cos(x);
x = 0;
y = 1;
h = 0.2;
xn = 1;
N = (xn - x)/h;
disp('       x               y ')
for i = 1:N
    k1 = h * f(x,y);
    k2 = h * f(x + h/2, y + k1/2);
    k3 = h * f(x + h/2, y + k2/2);
    k4 = h * f(x + h, y + k3);
    y = y + (k1 + 2*k2 + 2*k3 + k4)/6;
    x = x + h;
    fprintf('%f\t%f\n', x, y);
end
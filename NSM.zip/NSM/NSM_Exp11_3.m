x = [0 5 10 15 20];
y = [100 200 450 950 2000];
n = length(x);
xbar = mean(x);
ybar = mean(y);
a = sum((x - xbar) .* (y - ybar));
b = sqrt(sum((x - xbar).^2) * sum((y - ybar).^2));
r = a / b;
fprintf('Correlation coefficient = %.4f\n', r);

% --- Regression Lines ---
Sx = sqrt((x - xbar).^2);
Sy = sqrt((y - ybar).^2);
byx = (r * Sy) / Sx;
bxy = (r * Sx) / Sy;
fprintf('y - %.2f = %.4f(x - %.2f)\n', ybar, byx, xbar);
fprintf('x - %.2f = %.4f(y - %.2f)\n', xbar, bxy, ybar);
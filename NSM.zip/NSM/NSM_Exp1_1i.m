clc;
clear all;
f=@(x) x^2-29;
h=1;
N=10;
for i=-N:h:N
 if f(i)*f(i+h)<0
  a=i
  b=i+h
 end
end
f = @(x) 9*exp(-x)*sin(2*pi*x) - 3.5;
x0 = 3.5;
ep=10^(-5);
g = @(x) 9*exp(-x).*(2*pi*cos(2*pi*x) - sin(2*pi*x));
k=1;
n=100;
while k<=n
    x1=x0-(f(x0)/g(x0));
    if abs(x1-x0)<ep
        break;
    end 
        k=k+1;
        x0=x1;
end
fprintf('The solution is %f and no. of iterations are %d' , x1, k);
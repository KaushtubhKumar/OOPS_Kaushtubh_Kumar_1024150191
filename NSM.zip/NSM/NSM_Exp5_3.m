A = [60 -40 0;
     -40 150 -100;
     0 -100 130];
b = [200;
     0;
     230];
n = 3;
N = 100;
tol = 1e-3;
x0 = zeros(n,1);
x  = zeros(n,1);
for k = 1:N
    for i = 1:n
        sum1 = A(i,1:i-1) * x(1:i-1);
        sum2 = A(i,i+1:n) * x0(i+1:n);
        x(i) = (b(i) - sum1 - sum2) / A(i,i);
    end
    if abs(x - x0) < tol
        fprintf('Converged in %d iterations\n', k);
        fprintf('i1 = %.3f\n', x(1));
        fprintf('i2 = %.3f\n', x(2));
        fprintf('i3 = %.3f\n', x(3));
        return;
    end
    x0 = x;
end
fprintf('Did not converge in %d iterations\n', N);
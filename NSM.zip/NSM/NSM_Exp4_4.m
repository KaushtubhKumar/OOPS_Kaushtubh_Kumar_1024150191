a = [ 5   5   0   0   0   5.5;
      0   0   1  -1  -1   0;
      0   0   0   2  -3   0;
      1  -1  -1   0   0   0;
      0   5  -7  -2   0   0 ];
n = size(a,1);
for j = 1:n-1
    if a(j,j) == 0
        for k = j+1:n
            if a(k,j) ~= 0
                temp = a(j,:);
                a(j,:) = a(k,:);
                a(k,:) = temp;
                break;
            end
        end
    end
    for i = j+1:n
        m = a(i,j) / a(j,j)
        a(i,:) = a(i,:) - m * a(j,:)
    end
end
x = zeros(n,1);
x(n) = a(n,n+1) / a(n,n);
for i = n-1:-1:1
    sum = 0;
    for j = i+1:n
        sum = sum + a(i,j) * x(j);
    end
    x(i) = (a(i,n+1) - sum) / a(i,i);
end
x
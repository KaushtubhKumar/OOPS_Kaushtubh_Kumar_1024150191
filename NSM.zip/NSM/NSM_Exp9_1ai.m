f = @(x,y) -y + 2*cos(x);
x0 = 0;
y0 = 1;
h = 0.2;
xn = 1;
N = (xn - x0)/h;
x = zeros(1, N+1);
y = zeros(1, N+1);
x(1) = x0;
y(1) = y0;
for i = 1:N
    x(i+1) = x(i) + h;
    y_p = y(i) + h * f(x(i), y(i));
    y(i+1) = y(i) + (h/2) * ( f(x(i), y(i)) + f(x(i+1), y_p) );
end
disp('         x         y ')
disp([x' y'])
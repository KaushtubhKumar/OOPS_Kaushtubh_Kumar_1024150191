A = [10  8  -3   1;
      2 10   1  -4;
      3 -4  10   1;
      2  2  -3  10];
b = [16;
      9;
     10;
     11];
n = size(A,1);
N = 100;
tol = 1e-5;
x0 = zeros(n,1);
x  = zeros(n,1);
for k = 1:N
    for i = 1:n
        sum1 = A(i,1:i-1) * x(1:i-1);
        sum2 = A(i,i+1:n) * x0(i+1:n);
        x(i) = (b(i) - sum1 - sum2) / A(i,i);
    end
    if abs(x - x0) < tol
        fprintf('Converged in %d iterations\n', k);
        fprintf('x  = %.2f\n', x(1));
        fprintf('y  = %.2f\n', x(2));
        fprintf('z  = %.2f\n', x(3));
        fprintf('u  = %.2f\n', x(4));
        return;
    end
    x0 = x;
end
fprintf('Did not converge in %d iterations\n', N);
clc;
clear;
t = [0 0.1250 0.2500 0.3750 0.5000];
y = [0 6.24 7.75 4.85 0.0000];
T = input('Enter the value of T = ');
n = numel(t);
l = zeros(1, n);
for i = 1:n
    t1 = t;
    t1(i) = [];
    l(i) = prod(T-t1)./prod(t(i)-t1);
end
Y = sum(l.*y);
fprintf('Value of O at Y = %f is %f', T, Y);
A = [-4  2   0;
      2 -6   4;
      0  8 -16];
x = [1; 1; 0];
ep = 1e-3;
K_old = 0;
error = 1;
iter = 0;
while error > ep
    y = inv(A) * x;
    K = max(abs(y));
    x = y / K;
    error = abs(K - K_old);
    K_old = K;
    iter = iter + 1;
end
fprintf('Smallest Eigenvalue = %.6f\n', 1/K);
fprintf('Corresponding Eigenvector:\n');
disp(x);
fprintf('Number of iterations = %d\n', iter);